package view.interfaces;

import java.awt.*;

/**
 * Created by Jeff on 1/8/2018.
 */
public interface IPaintCanvas {
    Graphics2D getGraphics2D();
}
